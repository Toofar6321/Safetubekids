package com.safestream.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class SafetyResult(
    val score: Int, val verdict: String, val ageRating: String,
    val flags: List<String>, val summary: String, val recommendation: String
)

data class BlockEvent(
    val title: String, val channel: String, val score: Int,
    val reason: String, val timestamp: Long = System.currentTimeMillis()
)

private const val TAG             = "SafeStreamAI"
private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
private const val YT_TITLE_ID     = "$YOUTUBE_PACKAGE:id/title"
private const val YT_REEL_ID      = "$YOUTUBE_PACKAGE:id/reel_title"
private const val YT_MINI_ID      = "$YOUTUBE_PACKAGE:id/mini_title"
private const val YT_CHANNEL_ID   = "$YOUTUBE_PACKAGE:id/channel_name"

private val HARD_BLOCK = listOf(
    "scary prank", "prank on sister", "prank on brother",
    "extreme challenge", "gone wrong", "out of control",
    "needle injection", "dead bugs", "gross challenge",
    "killing", "murder", "horror", "demon", "stabbing", "shooting"
)

private val SOFT_FLAG = listOf(
    "prank", "challenge", "scare", "fight", "crash", "attack",
    "scary", "dangerous", "gross", "disgusting", "hate", "roast",
    "destroyed", "embarrassed", "revenge"
)

private val BLOCKED_CHANNELS = setOf(
    "KidsSuper777", "GrossKidz", "FamilyFunPacks", "DadReacts"
)

class SafeAccessibilityService : AccessibilityService() {

    private val scope       = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())
    private val http        = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private var lastTitle   = ""
    private var lastTime    = 0L
    private val DEBOUNCE    = 5_000L
    private val titleCache  = mutableMapOf<String, SafetyResult>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes   = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                           AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            packageNames = arrayOf(YOUTUBE_PACKAGE)
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        Log.i(TAG, "SafeStream connected")
        sendBroadcast(Intent("com.safestream.STATUS").putExtra("status", "RUNNING"))
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        sendBroadcast(Intent("com.safestream.STATUS").putExtra("status", "STOPPED"))
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.packageName != YOUTUBE_PACKAGE) return
        val root = rootInActiveWindow ?: return
        val (title, channel) = extractInfo(root) ?: return

        val now = System.currentTimeMillis()
        if (title == lastTitle && now - lastTime < DEBOUNCE) return
        lastTitle = title
        lastTime  = now

        Log.d(TAG, "Video: \"$title\" — $channel")
        sendBroadcast(Intent("com.safestream.DETECTION")
            .putExtra("title", title).putExtra("channel", channel))

        if (BLOCKED_CHANNELS.any { channel.contains(it, ignoreCase = true) }) {
            block(title, channel, 0, "Channel permanently blocked")
            return
        }

        if (HARD_BLOCK.any { title.lowercase().contains(it) }) {
            block(title, channel, 5, "Contains blocked keyword")
            return
        }

        titleCache[title]?.let { cached ->
            if (cached.score < threshold() || cached.verdict == "BLOCKED")
                block(title, channel, cached.score, cached.flags.firstOrNull() ?: "Previously blocked")
            return
        }

        analyseWithClaude(title, channel)
    }

    private fun extractInfo(root: AccessibilityNodeInfo): Pair<String, String>? {
        for (id in listOf(YT_TITLE_ID, YT_REEL_ID, YT_MINI_ID)) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id)
            if (nodes.isNotEmpty()) {
                val t = nodes[0].text?.toString()?.trim() ?: continue
                if (t.isNotBlank()) {
                    val ch = root.findAccessibilityNodeInfosByViewId(YT_CHANNEL_ID)
                        .firstOrNull()?.text?.toString()?.trim() ?: "Unknown"
                    return Pair(t, ch)
                }
            }
        }
        return null
    }

    private fun analyseWithClaude(title: String, channel: String) {
        scope.launch {
            try {
                val result = callClaude(title, channel)
                titleCache[title] = result
                sendBroadcast(Intent("com.safestream.ANALYSIS").apply {
                    putExtra("title", title)
                    putExtra("score", result.score)
                    putExtra("verdict", result.verdict)
                    putExtra("summary", result.summary)
                    putStringArrayListExtra("flags", ArrayList(result.flags))
                })
                if (result.score < threshold() || result.verdict == "BLOCKED")
                    block(title, channel, result.score, result.flags.firstOrNull() ?: result.summary)
            } catch (e: Exception) {
                Log.w(TAG, "Claude failed: ${e.message} — blocking (fail-closed)")
                block(title, channel, 0, "AI unavailable — blocked for safety")
            }
        }
    }

    private suspend fun callClaude(title: String, channel: String): SafetyResult =
        withContext(Dispatchers.IO) {
            val key = getSharedPreferences("safestream_prefs", MODE_PRIVATE)
                .getString("claude_api_key", "") ?: ""
            if (key.isBlank()) throw IOException("No API key set")

            val prompt = "You are a child safety moderator for kids 2-12.\n\n" +
                "Title: $title\nChannel: $channel\n\n" +
                "Return ONLY valid JSON, no markdown:\n" +
                "{\"safetyScore\":<0-100>,\"verdict\":\"SAFE\"|\"REVIEW\"|\"BLOCKED\"," +
                "\"ageRating\":\"All Ages\"|\"4+\"|\"6+\"|\"8+\"|\"Not for Kids\"," +
                "\"flags\":[<up to 3 concerns or []>]," +
                "\"summary\":\"<1 sentence>\",\"recommendation\":\"<1 sentence>\"}"

            val body = JSONObject().apply {
                put("model", "claude-sonnet-4-20250514")
                put("max_tokens", 400)
                put("messages", JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    }
                ))
            }.toString().toRequestBody("application/json".toMediaType())

            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .addHeader("x-api-key", key)
                .addHeader("anthropic-version", "2023-06-01")
                .post(body).build()

            val resp = http.newCall(req).execute()
            val raw  = resp.body?.string() ?: throw IOException("Empty response")
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: $raw")

            val text = JSONObject(raw)
                .getJSONArray("content").getJSONObject(0).getString("text")
                .replace("```json", "").replace("```", "").trim()

            val json  = JSONObject(text)
            val flags = mutableListOf<String>().also { list ->
                json.optJSONArray("flags")?.let {
                    for (i in 0 until it.length()) list.add(it.getString(i))
                }
            }

            SafetyResult(
                json.optInt("safetyScore", 50),
                json.optString("verdict", "REVIEW"),
                json.optString("ageRating", "?"),
                flags,
                json.optString("summary", ""),
                json.optString("recommendation", "")
            )
        }

    private fun block(title: String, channel: String, score: Int, reason: String) {
        mainHandler.post {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Toast.makeText(this, "SafeStream: Blocked", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, BlockOverlayActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra("title",   title)
                putExtra("channel", channel)
                putExtra("score",   score)
                putExtra("reason",  reason)
            })
        }
        BlockEventLogger.log(this, BlockEvent(title, channel, score, reason))
        sendBroadcast(Intent("com.safestream.BLOCK").apply {
            putExtra("title",     title)
            putExtra("channel",   channel)
            putExtra("score",     score)
            putExtra("reason",    reason)
            putExtra("timestamp", System.currentTimeMillis())
        })
    }

    private fun threshold() =
        getSharedPreferences("safestream_prefs", MODE_PRIVATE).getInt("threshold", 75)
}
